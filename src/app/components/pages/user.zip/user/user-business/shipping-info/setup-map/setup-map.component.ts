import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setup-map',
  templateUrl: './setup-map.component.html',
  styleUrls: ['./setup-map.component.scss']
})
export class SetupMapComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
