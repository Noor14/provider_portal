import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-business-setup',
  templateUrl: './business-setup.component.html',
  styleUrls: ['./business-setup.component.scss']
})
export class BusinessSetupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
