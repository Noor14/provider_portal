import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-business',
  templateUrl: './user-business.component.html',
  styleUrls: ['./user-business.component.scss']
})
export class UserBusinessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
